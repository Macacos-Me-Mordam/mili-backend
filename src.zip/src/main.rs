mod config;
mod modules;

use axum::Router;
use dotenvy::dotenv;
use std::env;
use std::sync::Arc;

use crate::config::{app_state::AppState, database};
use crate::modules::users::routes::user_routes;

#[tokio::main]
async fn main() {
    dotenv().ok();

    let db = database::connect().await;
    let keycloak_public_key = Arc::new(
        env::var("KEYCLOAK_PUBLIC_KEY").expect("Missing KEYCLOAK_PUBLIC_KEY")
    );

    let app_state = AppState { db, keycloak_public_key };

    let app = Router::new()
        .nest("/user", user_routes())
        .with_state(app_state);

    let port = env::var("PORT").unwrap_or_else(|_| "3000".to_string());
    let addr = format!("0.0.0.0:{}", port);

    println!("🚀 Server running on http://{}", addr);

    let listener = tokio::net::TcpListener::bind(&addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
