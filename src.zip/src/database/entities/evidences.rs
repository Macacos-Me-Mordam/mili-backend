use sea_orm::entity::prelude::*;
use sea_orm::RelationDef;
use serde::{Serialize, Deserialize};

use crate::database::entities::{camera, occurrences};

#[derive(Clone, Debug, PartialEq, DeriveEntityModel, Serialize, Deserialize)]
#[sea_orm(table_name = "evidences")]
pub struct Model {
    #[sea_orm(primary_key)]
    pub id: i32,
    pub name: String,
    pub camera_id: i32,
    pub occurrence_id: i32,
    pub created_at: DateTimeWithTimeZone,
}

#[derive(Copy, Clone, Debug, EnumIter, DeriveRelation)]
pub enum Relation {
    #[sea_orm(
        belongs_to = "camera::Entity",
        from = "Column::CameraId",
        to = "camera::Column::Id"
    )]
    Camera,

    #[sea_orm(
        belongs_to = "occurrences::Entity",
        from = "Column::OccurrenceId",
        to = "occurrences::Column::Id"
    )]
    Occurrences,
}

impl ActiveModelBehavior for ActiveModel {}

impl Related<camera::Entity> for Entity {
    fn to() -> RelationDef {
        Relation::Camera.def()
    }
}

impl Related<occurrences::Entity> for Entity {
    fn to() -> RelationDef {
        Relation::Occurrences.def()
    }
}
